import { BrowserModule,  } from '@angular/platform-browser';
import { NgModule,  } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations'

import { ClarityModule } from 'clarity-angular';

import { AppComponent } from './app.component';

import { NguiMenuDirective} from './Components/Menu/menu.directive'


@NgModule({
  declarations: [
    AppComponent,
    NguiMenuDirective
  ],
  imports: [
    BrowserModule,
    ClarityModule.forRoot(),
    BrowserAnimationsModule

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
